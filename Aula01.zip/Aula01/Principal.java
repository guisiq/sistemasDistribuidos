package Aula01;

public class Principal {
    public static void main(String args[]) throws InterruptedException {

        String nameThread = Thread.currentThread().getName();


        MinhaThread m1 = new MinhaThread();
        Thread t1 = new Thread(m1);
        t1.start();

        for(int i=11; i<=20; i++){
            System.out.print( nameThread + " : ");
            System.out.println(i);
            Thread.sleep(500);
        }
    }
}
