package Aula02.ThreadComInterface;

public class MinhaThread implements Runnable {
    @Override
    public void run() {
        String nameThread = Thread.currentThread().getName();
        for(int i=1; i<=10; i++){
            try {
                System.out.println( nameThread + " : " + i);
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
