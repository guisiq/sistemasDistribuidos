package Aula02.ProblemaCritico;

public class Contador {
    private int cont = 0;

    public  void incrementar(){
        cont ++;
    }
    public int getCont(){
        return cont;
    }
}
