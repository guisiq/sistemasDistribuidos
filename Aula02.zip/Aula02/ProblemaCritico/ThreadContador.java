package Aula02.ProblemaCritico;

public class ThreadContador extends Thread {
    private Contador contador;

    public ThreadContador(Contador c){
        contador = c;
    }

    public void run() {
        for (int i=0; i<1000; i++){
            contador.incrementar();
        }

    }
}
